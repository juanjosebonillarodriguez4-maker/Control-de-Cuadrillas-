# Secadora El Viñedo — Control de Cuadrillas

Proyecto Android inicial, con base de datos local SQLite y funcionamiento sin internet.

## Funciones incluidas en esta primera versión
- Registrar trabajadores y cuadrillas.
- Marcar asistencia diaria.
- Registrar movimientos por cuadrilla con tipo, cantidad, tarifa e importe.
- Tarifas editables desde el formulario de movimientos.
- Ver el total generado por cuadrilla en la fecha seleccionada.
- Registrar el método de reparto diario:
  - repartir el total entre presentes; o
  - reparto especial autorizado por el encargado.
- Guardar los datos en el teléfono, sin conexión.

## Generar el APK
Este repositorio incluye `.github/workflows/android.yml`.
1. Sube todos los archivos y carpetas del ZIP al repositorio de GitHub.
2. Abre la pestaña **Actions**.
3. Selecciona **Construir APK Android** y pulsa **Run workflow** si no se inicia automáticamente.
4. Cuando termine, abre la ejecución y descarga el artefacto **Secadora-El-Vinedo-debug-apk**.
5. Descomprime el artefacto y encontrarás `app-debug.apk`.

## Importante
- Esta es una versión inicial para probar. Antes de usarla para pagos reales, comprueba los cálculos con datos de la empresa.
- El reparto especial por ausencias necesita que el encargado introduzca/autorice la decisión; la aplicación no inventa una regla.
- Los datos se guardan solo en el teléfono. Desinstalar la aplicación puede borrar los datos. Todavía no se incluye restauración automática desde copia de seguridad.
- La APK se construye en GitHub Actions; este ZIP contiene el proyecto fuente, no un APK ya compilado.
