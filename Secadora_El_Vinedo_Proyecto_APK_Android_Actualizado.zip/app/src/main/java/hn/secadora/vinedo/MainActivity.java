package hn.secadora.vinedo;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Typeface;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.content.ContentValues;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, content;
    final String[] tipos = {"1","1.5","2","2.5","3","4","5","6","7"};
    final String[] etiquetas = {"Movimiento 1","Movimiento 1.5","Movimiento 2","Movimiento 2.5","Movimiento 3","Movimiento 4","Movimiento 5","Movimiento 6","Movimiento 7"};
    final double[] tarifasIniciales = {0,0,0,0,0,0,0,0,0};
    String fecha;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        fecha = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        construirInicio();
    }

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    TextView texto(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xFF172B26); t.setPadding(dp(4),dp(8),dp(4),dp(8));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    Button boton(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        b.setOnClickListener(v -> r.run()); return b;
    }
    void base(String titulo) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F7F5);
        TextView head = texto("SECADORA EL VIÑEDO\n" + titulo, 20, true);
        head.setTextColor(0xFFFFFFFF); head.setBackgroundColor(0xFF145B43);
        head.setPadding(dp(18),dp(18),dp(18),dp(18)); root.addView(head);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setPadding(dp(14),dp(10),dp(14),dp(24));
        content.setOrientation(LinearLayout.VERTICAL); scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void construirInicio() {
        base("CONTROL DE CUADRILLAS");
        content.addView(texto("Control diario de movimientos, asistencia y reparto.",16,false));
        content.addView(texto("Fecha: " + fecha, 14, true));
        content.addView(boton("➕ Registrar trabajador", this::nuevoTrabajador));
        content.addView(boton("👥 Crear cuadrilla", this::nuevaCuadrilla));
        content.addView(boton("📋 Marcar asistencia", this::asistencia));
        content.addView(boton("⚖️ Registrar movimiento por cuadrilla", this::movimiento));
        content.addView(boton("💵 Calcular reparto diario", this::reparto));
        content.addView(boton("📊 Ver resumen de hoy", this::resumen));
        content.addView(boton("⚙️ Editar tarifas", this::editarTarifas));
        content.addView(boton("ℹ️ Ayuda", this::ayuda));
    }
    EditText campo(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); return e;
    }
    void mensaje(String s) { new AlertDialog.Builder(this).setMessage(s).setPositiveButton("Aceptar",null).show(); }
    void pedirTexto(String titulo, String hint, java.util.function.Consumer<String> alGuardar) {
        EditText e = campo(hint);
        new AlertDialog.Builder(this).setTitle(titulo).setView(e)
          .setNegativeButton("Cancelar",null)
          .setPositiveButton("Guardar",(d,w)->{String s=e.getText().toString().trim(); if(!s.isEmpty()) alGuardar.accept(s);})
          .show();
    }
    void nuevoTrabajador() {
        pedirTexto("Nuevo trabajador","Nombre completo", nombre -> {
            ContentValues v=new ContentValues(); v.put("nombre",nombre); db.getWritableDatabase().insert("trabajadores",null,v);
            mensaje("Trabajador guardado."); construirInicio();
        });
    }
    void nuevaCuadrilla() {
        pedirTexto("Nueva cuadrilla","Nombre o número de cuadrilla", nombre -> {
            ContentValues v=new ContentValues(); v.put("nombre",nombre); db.getWritableDatabase().insert("cuadrillas",null,v);
            mensaje("Cuadrilla guardada."); construirInicio();
        });
    }
    String[] lista(String tabla) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT nombre FROM "+tabla+" ORDER BY nombre",null);
        String[] a=new String[c.getCount()]; int i=0; while(c.moveToNext()) a[i++]=c.getString(0); c.close(); return a;
    }
    long idPorNombre(String tabla,String nombre) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id FROM "+tabla+" WHERE nombre=?",new String[]{nombre});
        long id=-1; if(c.moveToFirst())id=c.getLong(0); c.close(); return id;
    }
    void asistencia() {
        String[] cuadrillas=lista("cuadrillas"), trabajadores=lista("trabajadores");
        if(cuadrillas.length==0 || trabajadores.length==0){mensaje("Primero registra al menos una cuadrilla y un trabajador.");return;}
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(8),dp(4),dp(8),dp(4)); box.setOrientation(LinearLayout.VERTICAL);
        Spinner sc=new Spinner(this); sc.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cuadrillas));
        Spinner st=new Spinner(this); st.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,trabajadores));
        Spinner estado=new Spinner(this); estado.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Presente","Ausente"}));
        EditText f=campo("Fecha AAAA-MM-DD"); f.setText(fecha);
        box.addView(texto("Cuadrilla",14,true));box.addView(sc);box.addView(texto("Trabajador",14,true));box.addView(st);
        box.addView(texto("Asistencia",14,true));box.addView(estado);box.addView(f);
        new AlertDialog.Builder(this).setTitle("Registrar asistencia").setView(box)
          .setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{
            ContentValues v=new ContentValues();v.put("cuadrilla_id",idPorNombre("cuadrillas",sc.getSelectedItem().toString()));
            v.put("trabajador_id",idPorNombre("trabajadores",st.getSelectedItem().toString()));v.put("fecha",f.getText().toString().trim());
            v.put("estado",estado.getSelectedItem().toString());db.getWritableDatabase().insertWithOnConflict("asistencia",null,v,SQLiteDatabase.CONFLICT_REPLACE);
            mensaje("Asistencia guardada.");});
    }
    void movimiento() {
        String[] cuadrillas=lista("cuadrillas");
        if(cuadrillas.length==0){mensaje("Primero crea una cuadrilla.");return;}
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(8),0,dp(8),0);box.setOrientation(LinearLayout.VERTICAL);
        Spinner sc=new Spinner(this);sc.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cuadrillas));
        Spinner sm=new Spinner(this);sm.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,etiquetas));
        EditText f=campo("Fecha AAAA-MM-DD");f.setText(fecha);
        EditText cantidad=campo("Cantidad");cantidad.setInputType(8194);
        EditText tarifa=campo("Tarifa por unidad (L.)");tarifa.setInputType(8194);
        EditText cliente=campo("Cliente / observaciones");
        int pos=sm.getSelectedItemPosition();
        box.addView(texto("Cuadrilla",14,true));box.addView(sc);box.addView(texto("Tipo de movimiento",14,true));box.addView(sm);
        box.addView(f);box.addView(cantidad);box.addView(tarifa);box.addView(cliente);
        new AlertDialog.Builder(this).setTitle("Movimiento de cuadrilla").setView(box)
          .setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{
            try{
              double q=Double.parseDouble(cantidad.getText().toString().trim());
              double rate=Double.parseDouble(tarifa.getText().toString().trim());
              ContentValues v=new ContentValues();v.put("cuadrilla_id",idPorNombre("cuadrillas",sc.getSelectedItem().toString()));
              v.put("tipo",sm.getSelectedItem().toString());v.put("cantidad",q);v.put("tarifa",rate);v.put("total",q*rate);
              v.put("fecha",f.getText().toString().trim());v.put("nota",cliente.getText().toString().trim());
              db.getWritableDatabase().insert("movimientos",null,v);mensaje("Movimiento guardado. Total: L. "+String.format(Locale.US,"%.2f",q*rate));
            }catch(Exception ex){mensaje("Ingresa una cantidad y una tarifa válidas.");}
          }).show();
    }
    void reparto() {
        String[] cuadrillas=lista("cuadrillas");
        if(cuadrillas.length==0){mensaje("Primero crea una cuadrilla.");return;}
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(8),0,dp(8),0);box.setOrientation(LinearLayout.VERTICAL);
        Spinner sc=new Spinner(this);sc.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cuadrillas));
        EditText f=campo("Fecha AAAA-MM-DD");f.setText(fecha);
        Spinner modo=new Spinner(this);modo.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Repartir total entre presentes","Reparto especial autorizado por encargado"}));
        box.addView(sc);box.addView(f);box.addView(texto("Regla de reparto",14,true));box.addView(modo);
        new AlertDialog.Builder(this).setTitle("Calcular reparto").setView(box)
          .setNegativeButton("Cancelar",null).setPositiveButton("Calcular",(d,w)->{
            long cid=idPorNombre("cuadrillas",sc.getSelectedItem().toString());String day=f.getText().toString().trim();
            Cursor total=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM movimientos WHERE cuadrilla_id=? AND fecha=?",new String[]{""+cid,day});
            double amount=0;if(total.moveToFirst())amount=total.getDouble(0);total.close();
            Cursor present=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM asistencia WHERE cuadrilla_id=? AND fecha=? AND estado='Presente'",new String[]{""+cid,day});
            int n=0;if(present.moveToFirst())n=present.getInt(0);present.close();
            String result="Total de cuadrilla: L. "+String.format(Locale.US,"%.2f",amount)+"\nPresentes registrados: "+n+"\n";
            if(modo.getSelectedItemPosition()==0) result += n>0?"Parte por presente: L. "+String.format(Locale.US,"%.2f",amount/n):"No hay presentes registrados.";
            else result += "Reparto especial seleccionado. El encargado debe definir/confirmar la regla antes de registrar importes individuales.";
            mensaje(result);
          }).show();
    }
    void resumen() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT q.nombre,COALESCE(SUM(m.total),0) FROM cuadrillas q LEFT JOIN movimientos m ON q.id=m.cuadrilla_id AND m.fecha=? GROUP BY q.id ORDER BY q.nombre",new String[]{fecha});
        StringBuilder s=new StringBuilder("Resumen del "+fecha+"\n\n");
        while(c.moveToNext())s.append(c.getString(0)).append(": L. ").append(String.format(Locale.US,"%.2f",c.getDouble(1))).append("\n");
        c.close();mensaje(s.toString());
    }
    void editarTarifas() {
        String[] nombres=etiquetas;
        Spinner sm=new Spinner(this);sm.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,nombres));
        EditText rate=campo("Nueva tarifa en lempiras");rate.setInputType(8194);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(sm);box.addView(rate);
        new AlertDialog.Builder(this).setTitle("Editar tarifa").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{
            try{ContentValues v=new ContentValues();v.put("tarifa",Double.parseDouble(rate.getText().toString().trim()));
                db.getWritableDatabase().insertWithOnConflict("tarifas",null,tarifaValues(sm.getSelectedItem().toString(),Double.parseDouble(rate.getText().toString().trim())),SQLiteDatabase.CONFLICT_REPLACE);
                mensaje("Tarifa guardada. Recuerda verificarla al registrar movimientos.");
            }catch(Exception e){mensaje("Escribe una tarifa válida.");}
        }).show();
    }
    ContentValues tarifaValues(String tipo,double t){ContentValues v=new ContentValues();v.put("tipo",tipo);v.put("tarifa",t);return v;}
    void ayuda() {
        mensaje("1. Registra trabajadores y cuadrillas.\n2. Marca asistencia cada día.\n3. Registra movimientos de la cuadrilla e indica cantidad y tarifa.\n4. Calcula el reparto. El reparto especial por ausencias requiere decisión del encargado.\n\nEsta versión inicial guarda los datos localmente. Verifica los importes antes de utilizarla para pagos reales.");
    }

    class DB extends android.database.sqlite.SQLiteOpenHelper {
        DB(Context c){super(c,"vinedo_cuadrillas.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE trabajadores(id INTEGER PRIMARY KEY AUTOINCREMENT,nombre TEXT UNIQUE)");
            d.execSQL("CREATE TABLE cuadrillas(id INTEGER PRIMARY KEY AUTOINCREMENT,nombre TEXT UNIQUE)");
            d.execSQL("CREATE TABLE asistencia(cuadrilla_id INTEGER,trabajador_id INTEGER,fecha TEXT,estado TEXT,PRIMARY KEY(cuadrilla_id,trabajador_id,fecha))");
            d.execSQL("CREATE TABLE movimientos(id INTEGER PRIMARY KEY AUTOINCREMENT,cuadrilla_id INTEGER,tipo TEXT,cantidad REAL,tarifa REAL,total REAL,fecha TEXT,nota TEXT)");
            d.execSQL("CREATE TABLE tarifas(tipo TEXT PRIMARY KEY,tarifa REAL)");
        }
        public void onUpgrade(SQLiteDatabase d,int oldVersion,int newVersion){}
    }
}
